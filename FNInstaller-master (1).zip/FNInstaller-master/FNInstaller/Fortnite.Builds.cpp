#include <windows.h>
#include <wininet.h>
#include <conio.h>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
#include <map>
#include <filesystem>
#include <fstream>
#include <thread>
#include <atomic>
#include <algorithm>
#include <chrono>
#include <mutex>
#include <iostream>
std::atomic<int> completedChunks = 0;
std::atomic<int> activeThreads = 0;
std::atomic<unsigned long long> bytesDownloaded = 0;

std::vector<float> speedSamples;
std::mutex speedMutex;
std::vector<float> chunkTimes;
std::mutex chunkMutex;
std::atomic<unsigned long long> totalBytes = 0;

long long lastSecondBytes = 0;
long long lastTime = 0;

#include "sha1.h"
namespace fs = std::filesystem;

#include "json.hpp" 
using json = nlohmann::json;

#pragma comment(lib, "wininet.lib")

#define BASE_URL "https://cdn2.andr1ww.dev"

struct VersionInfo {
    std::string name;
    std::string manifest_url;
    std::string chunks_url;
};

struct DownloadEntry {
    std::string version;
    std::string manifest_url;
    std::string chunks_url;

    float progress = 0.f;
    int numChunksRemaining = 0;
    float speed = 0.f;

    std::string dest_folder;
};

struct Info {
    std::string Name;
    size_t FileOffset;
    size_t Start;
    size_t End;
};

struct Manifest {
    std::vector<std::string> Empties;
    std::map<std::string, std::vector<Info>> ChunkInfos;
};

void from_json(const json& j, Info& info) {
    j.at("name").get_to(info.Name);
    j.at("offset").get_to(info.FileOffset);
    j.at("start").get_to(info.Start);
    j.at("end").get_to(info.End);
}

void from_json(const json& j, Manifest& manifest) {
    j.at("empty").get_to(manifest.Empties);
    j.at("chunks").get_to(manifest.ChunkInfos);
}

unsigned char* DownloadToBuffer(const char* url, size_t* outSize = nullptr)
{
    HINTERNET hInternet = InternetOpenA("Launcher", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
    if (!hInternet) return NULL;

    DWORD timeout = 10000; 

    InternetSetOptionA(hInternet, INTERNET_OPTION_CONNECT_TIMEOUT, &timeout, sizeof(timeout));
    InternetSetOptionA(hInternet, INTERNET_OPTION_RECEIVE_TIMEOUT, &timeout, sizeof(timeout));
    InternetSetOptionA(hInternet, INTERNET_OPTION_SEND_TIMEOUT, &timeout, sizeof(timeout));

    HINTERNET hConnect = InternetOpenUrlA(hInternet, url, NULL, 0, INTERNET_FLAG_RELOAD, 0);
    if (!hConnect) {
        InternetCloseHandle(hInternet);
        return NULL;
    }

    unsigned char* buffer = NULL;
    size_t total = 0;

    const size_t CHUNK = 1024768;
    auto temp = malloc(CHUNK);

    DWORD read = 0;
    while (InternetReadFile(hConnect, temp, CHUNK, &read) && read > 0)
    {
        bytesDownloaded += read;

        auto newBuf = (unsigned char*)realloc(buffer, total + read);
        if (!newBuf) break;

        buffer = newBuf;
        memcpy(buffer + total, temp, read);
        total += read;
    }

    free(temp);
    InternetCloseHandle(hConnect);
    InternetCloseHandle(hInternet);

    if (outSize) *outSize = total;
    return buffer;
}

void FormatETA(char* buf, size_t sz, float seconds)
{
    if (seconds <= 0.f || seconds > 360000.f)
    {
        sprintf_s(buf, sz, "calculating...");
        return;
    }

    int s = (int)seconds;
    int h = s / 3600; s %= 3600;
    int m = s / 60;   s %= 60;

    if (h > 0) sprintf_s(buf, sz, "%dh %dm %ds", h, m, s);
    else if (m > 0) sprintf_s(buf, sz, "%dm %ds", m, s);
    else sprintf_s(buf, sz, "%ds", s);
}

std::vector<VersionInfo> FetchVersions()
{
    size_t size = 0;
    auto data = DownloadToBuffer("https://cdn2.andr1ww.dev/versions.json", &size);

    if (!data) return {};

    std::string str((char*)data, size);
    free(data);

    json j = json::parse(str);

    std::vector<VersionInfo> versions;

    if (!j.is_object())
        return {};

    for (auto& [key, value] : j.items())
    {
        if (!value.is_object())
            continue;

        VersionInfo v;
        v.name = key;

        if (value.contains("manifest") && value["manifest"].is_string())
            v.manifest_url = value["manifest"];

        if (value.contains("chunks") && value["chunks"].is_string())
            v.chunks_url = value["chunks"];

        versions.push_back(v);
    }

    return versions;
}

float GetVersion(const std::string& name)
{
    size_t start = name.find("Release-");
    if (start == std::string::npos) return 0;

    start += 8; 
    size_t end = name.find("-CL-", start);

    std::string verStr = name.substr(start, end - start);
    return std::stof(verStr);
}

int ShowMenu(std::vector<VersionInfo>& items)
{
    int selected = 0;

    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO info{ 100, FALSE };
    SetConsoleCursorInfo(h, &info);

    std::sort(items.begin(), items.end(), [](const VersionInfo& a, const VersionInfo& b)
        {
            return GetVersion(a.name) < GetVersion(b.name); 
        });

    while (true)
    {
        system("cls");

        printf("Thanks for using my downloader! This is a work in progress, so expect some issues here and there. - andr1ww\n");
		printf("Thanks ploosh (https://github.com/plooshi) for providing the chunker & base downloader that this relies on.\n\n");
		printf("Navigate through the builds using the arrow keys and press enter to select.\n");
        printf("Select Build:\n\n");

        int menuStartY = 5;

        while (true)
        {
            COORD pos = { 0, (SHORT)menuStartY };
            SetConsoleCursorPosition(h, pos);

            for (int i = 0; i < items.size(); i++)
            {
                if (i == selected)
                    printf(" > %-80s\n", items[i].name.c_str());
                else
                    printf("   %-80s\n", items[i].name.c_str());
            }

            int key = _getch();

            if (key == 224)
            {
                key = _getch();

                if (key == 72)
                    selected = (selected - 1 + items.size()) % items.size();
                else if (key == 80)
                    selected = (selected + 1) % items.size();
            }
            else if (key == 13)
            {
                return selected;
            }
        }
    }
}

unsigned char* downloadChunk(DownloadEntry* entry, const std::string& hash)
{
    auto url = entry->chunks_url + hash + ".chunk";

    size_t size = 0;
    auto data = DownloadToBuffer(url.c_str(), &size);

    if (!data)
        return downloadChunk(entry, hash);

    sha1::SHA1 sha;
    sha.processBytes(data, size);

    uint32_t digest[5];
    sha.getDigest(digest);

    char tmp[48];
    snprintf(tmp, sizeof(tmp), "%08x%08x%08x%08x%08x",
        digest[0], digest[1], digest[2], digest[3], digest[4]);

    if (hash != tmp)
    {
        free(data);
        return downloadChunk(entry, hash); 
    }

    return data;
}

std::vector<std::string> CompletedChunks;
std::atomic<int> totalChunks = 0;

void ExtractionThread(
    DownloadEntry* entry,
    std::string chunkHash,
    std::vector<Info> files,
    std::filesystem::path folder)
{
    auto t1 = std::chrono::high_resolution_clock::now();

    activeThreads++;

    auto chunk = downloadChunk(entry, chunkHash);
    if (!chunk)
    {
        activeThreads--;
        return;
    }

    for (auto& file : files)
    {
        auto path = folder / file.Name;
        std::filesystem::create_directories(path.parent_path());

        HANDLE hFile = CreateFileW(
            path.c_str(),
            GENERIC_READ | GENERIC_WRITE,
            0,
            NULL,
            OPEN_ALWAYS,
            FILE_ATTRIBUTE_NORMAL,
            NULL);

        while (hFile == INVALID_HANDLE_VALUE)
        {
            Sleep(25);
            hFile = CreateFileW(
                path.c_str(),
                GENERIC_READ | GENERIC_WRITE,
                0,
                NULL,
                OPEN_ALWAYS,
                FILE_ATTRIBUTE_NORMAL,
                NULL);
        }

        LARGE_INTEGER offset;
        offset.QuadPart = file.FileOffset;

        SetFilePointerEx(hFile, offset, NULL, FILE_BEGIN);

        DWORD written;
        WriteFile(hFile,
            chunk + file.Start,
            (DWORD)(file.End - file.Start),
            &written,
            NULL);

        CloseHandle(hFile);
    }

    auto t2 = std::chrono::high_resolution_clock::now();
    float seconds = std::chrono::duration<float>(t2 - t1).count();

    {
        std::lock_guard<std::mutex> lock(chunkMutex);

        if (chunkTimes.size() >= 20)
            chunkTimes.erase(chunkTimes.begin());

        chunkTimes.push_back(seconds);
    }

    CompletedChunks.push_back(chunkHash);

    std::ofstream rmx(folder / ".dl");
    rmx << json(CompletedChunks).dump();
    rmx.close();

    free(chunk);

    int done = ++completedChunks;

    entry->progress = (float)done / totalChunks * 100.f;
    entry->numChunksRemaining = totalChunks - done;

    activeThreads--;
}

void DownloadThread(std::string folderStr, DownloadEntry* entry)
{
    std::filesystem::path folder = folderStr;

    size_t size = 0;
    auto data = DownloadToBuffer(entry->manifest_url.c_str(), &size);

    if (!data)
        return;

    auto manifest = json::parse(std::string((char*)data, size)).get<Manifest>();
    free(data);

    totalBytes = 0;

    for (auto& [hash, files] : manifest.ChunkInfos)
    {
        for (auto& f : files)
        {
            totalBytes += (f.End - f.Start);
        }
    }

    std::filesystem::create_directories(folder);

    for (auto& e : manifest.Empties)
    {
        auto file = folder / e;
        std::filesystem::create_directories(file.parent_path());
        std::ofstream(file).close();
    }

    std::ifstream rmx(folder / ".dl");
    completedChunks = 0;

    if (rmx.good())
    {
        json j;
        rmx >> j;
        CompletedChunks = j.get<std::vector<std::string>>();

        for (auto& chunk : CompletedChunks)
        {
            if (manifest.ChunkInfos.erase(chunk))
                completedChunks++;
        }
    }

    totalChunks = manifest.ChunkInfos.size() + completedChunks;

    unsigned threads = std::thread::hardware_concurrency() / 2;
    if (threads == 0) threads = 2;

    for (auto& [hash, files] : manifest.ChunkInfos)
    {
        while (activeThreads > threads)
            Sleep(10);

        std::thread(ExtractionThread, entry, hash, files, folder).detach();
    }

    while (activeThreads > 0)
        Sleep(50);

    std::filesystem::path dlPath = folder / ".dl";

    for (int i = 0; i < 20; i++)
    {
        std::error_code ec;
        if (std::filesystem::remove(dlPath, ec))
            break;

        Sleep(50); 
    }
}

DownloadEntry CreateEntry(const VersionInfo& v)
{
    DownloadEntry e{};
    e.version = v.name;
    e.manifest_url = v.manifest_url;
    e.chunks_url = v.chunks_url;
    return e;
}

std::string AskDownloadFolder()
{
    std::string path;

    std::cout << "\nEnter download directory (leave empty for ./Builds):\n> ";
    std::getline(std::cin, path);

    path.erase(0, path.find_first_not_of(" \t\r\n"));
    path.erase(path.find_last_not_of(" \t\r\n") + 1);

    if (path.empty())
    {
        path = fs::current_path().string() + "\\Builds";
    }

    try
    {
        fs::create_directories(path); 
    }
    catch (const std::exception& e)
    {
        std::cerr << "Failed to create directory: " << e.what() << "\n";
        return "";
    }

    return path;
}
int main()
{
    auto versions = FetchVersions();

    if (versions.empty())
    {
        printf("Failed to get all hosted versions, contact andr1ww .\n");
        system("pause");
        return 1;
    }

    int selected = ShowMenu(versions);

    auto& chosen = versions[selected];

    printf("\nSelected: %s\n", chosen.name.c_str());

    std::string baseFolder = AskDownloadFolder();

    std::string fullPath = baseFolder + "\\" + chosen.name;

    auto entry = CreateEntry(chosen);

	printf("Starting download to directory: %s\n", fullPath.c_str());

    std::thread(DownloadThread, fullPath, &entry).detach();

    auto lastTime = std::chrono::high_resolution_clock::now();
    static float spd = 0.f;
    unsigned long long lastBytes = 0;

    while (entry.progress < 100.f)
    {
        auto now = std::chrono::high_resolution_clock::now();
        float dt = std::chrono::duration<float>(now - lastTime).count();

        unsigned long long currentBytes = bytesDownloaded.load();
        unsigned long long deltaBytes = currentBytes - lastBytes;

        float mbps = 0.f;

        if (dt > 0.f)
        {
            mbps = (deltaBytes / (1024.f * 1024.f)) / dt;

            std::lock_guard<std::mutex> lock(speedMutex);

            if (speedSamples.size() >= 10)
                speedSamples.erase(speedSamples.begin());

            speedSamples.push_back(mbps);
        }

        lastTime = now;
        lastBytes = currentBytes;

        float avgSpeed = 0.f;

        {
            std::lock_guard<std::mutex> lock(speedMutex);
            for (auto s : speedSamples)
                avgSpeed += s;

            if (!speedSamples.empty())
                avgSpeed /= speedSamples.size();
        }

        float eta = 0.f;

        if (avgSpeed > 0.01f)
        {
            double remainingBytes = (double)totalBytes - (double)bytesDownloaded.load();

            if (remainingBytes < 0)
                remainingBytes = 0;

            double bytesPerSec = avgSpeed * 1024.0 * 1024.0;

            eta = (float)(remainingBytes / bytesPerSec);
        }

        char etaBuf[64];
        FormatETA(etaBuf, sizeof(etaBuf), eta);

        char speedBuf[32];

        if (avgSpeed >= 1500.f)
            sprintf_s(speedBuf, "calculating...");
        else if (avgSpeed >= 1024.f)
            sprintf_s(speedBuf, "%.2f GB/s", avgSpeed / 1024.f);
        else if (avgSpeed >= 1.f)
            sprintf_s(speedBuf, "%.2f MB/s", avgSpeed);
        else
            sprintf_s(speedBuf, "%.0f KB/s", avgSpeed * 1024.f);

        printf("\rProgress: %.2f%% | Remaining: %d | Speed: %s | ETA: %s            ",
            entry.progress,
            entry.numChunksRemaining,
            speedBuf,
            etaBuf);

        Sleep(500);
    }

    printf("\nDownload complete.\n");
    system("pause");

    return 0;
} 
