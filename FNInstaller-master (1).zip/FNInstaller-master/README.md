# FNInstaller

This github repository contains the source code for the downloader **FNInstaller**

You can build the source, or you can download [here](https://github.com/andr1ww/FNInstaller/releases/download/1.0.0/FNInstaller.exe)!

If you would like to help support me with costs, please email me via me@andr1ww.dev

## Credits

- plooshi | download logic & chunker
- andr1ww | converting into a cli application & hosting a majority of the builds
